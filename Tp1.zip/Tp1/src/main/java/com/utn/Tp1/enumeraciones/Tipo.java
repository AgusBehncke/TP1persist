package com.utn.Tp1.enumeraciones;

public enum Tipo {
    Manufacturado,
    Insumo;

    private Tipo() {
    }
}
