package com.utn.Tp1.enumeraciones;

public enum TipoEnvio {
    Delivery,
    Retira;

    private TipoEnvio() {
    }
}

