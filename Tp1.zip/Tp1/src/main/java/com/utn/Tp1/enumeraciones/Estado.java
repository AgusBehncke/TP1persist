package com.utn.Tp1.enumeraciones;

public enum Estado {
    Iniciado,
    Entregado,
    Preparacion;
    private Estado() {
    }
}
