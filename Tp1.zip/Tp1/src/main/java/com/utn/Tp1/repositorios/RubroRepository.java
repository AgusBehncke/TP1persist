package com.utn.Tp1.repositorios;

import com.utn.Tp1.entidades.Rubro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RubroRepository extends JpaRepository<Rubro, Long> {
}
