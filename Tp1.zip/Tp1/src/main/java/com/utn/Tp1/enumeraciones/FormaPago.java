package com.utn.Tp1.enumeraciones;

public enum FormaPago {
    Efectivo,
    TC;

    private FormaPago() {
    }
}
